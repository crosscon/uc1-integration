Release Notes for MCU-Link Firmware
===================================

Version: 3.153
Date: 18 December 2024

Overview
========

MCU-Link is a new debug probe solution/architecture being developed for
NXP LPC, Kinetis, i.MX RT and MCX series MCU targets, intended as a replacement
for the standalone LPC-Link2 (OM13054) and various on-board debug probe solutions.

Product pages:
https://www.nxp.com/pages/:MCU-LINK
https://www.nxp.com/pages/:MCU-LINK-PRO


==================
CMSIS-DAP Firmware
==================

Scope
=====

The firmware supports:
 - MCU-Link stand-alone probe (LPC55S69 LQFP64 package)
 - MCU-Link MR probe (LPC55S69 LQFP64 package)
 - MCU-Link on-board probe solutions (LPC55S69 LQFP100, BGA98 or LQFP64 packages)
 - MCU-Link Pro probe (LPC55S69 LQFP100 or BGA98 packages)
 - MCU-Link Mini probe (LPC55S16 BGA59 package)


Release History
===============

 - V3.153 - Adds support for hardware flow-control for UART target interface on MCU-Link MR

 - V3.148 - Adds VCOM activity LED indication on MCU-Link Mini on-board probe variants
             - Includes updated SEGGER firmware version (240702)
             - Patches USB device stack vulnerability issues

 - V3.146 - Restricts the hold of target reset via DBGIF reset signal during initialization
            to MCU-Link on-board probes with support for energy measurement (to avoid potential
            target booting problems due to the disconnects on measurement circuit calibration)

 - V3.142 - Fixes a problem where MCU-Link connected to a powered USB hub being re-plugged to
            the host PC was causing subsequent firmware malfunction
          - Adds a quick flashing sequence to the USB_HOST LED while connecting/disconnecting
          - Program scripts on Windows now use waitfor utility instead of timeout

 - V3.141 - Adds CMSIS-DAP JTAG support for DAP TAP with 8-bit IR length

 - V3.140 - Introduces support for MCU-Link Mini
          - Hold target reset (via DBGIF reset signal) during MCU-Link on-board probe initialization
            to fix potential booting problems for target MCU

 - V3.133 - Fixes erratic data corruption during VCOM communication
          - Fixes a problem where the VCOM activity led may remain permanently on after using SWO trace
          - Addresses a self-reset problem where the probe might fail to reset while in use

 - V3.128 - Fixes a problem on MCU-Link on-board where re-plugging the debug USB cable
            while the probe remains powered by the target USB cable was causing subsequent
            firmware malfunction
          - Adds possibility to configure target identification strings for on-board probes
            connected to a known fixed target (available through CMSIS-DAP DAP_Info command)
          - Changes the product string to include actual board name (instead of 'on-board')
            when target identification strings are available

 - V3.122 - Introduces support for delivering SWO trace data over CMSIS-DAP for
            compatibility with third party IDEs
          - Fixes a potential problem on MCU-Link on-board where Energy Measurement
            source selection might temporarily disconnect the target MCU 
          - Includes updated SEGGER firmware version (230502)
          - Introduces support for automatic firmware upgrade (available in future
            MCUXpresso IDE 11.9.0 or later releases)

 - V3.108 - Updates to CMSIS-DAP 2.1 and uses WinUSB for communication to host PC
               Note: requires MCUXpresso IDE 11.7.0 or newer
             - Introduces support for target boot configuration control
             - Fixes simultaneous usage of USBSIO-I2C and debug services
             - Changes VCOM service to completely ignore DTR signal from host
             - Changes DBGIF_TCK_SWCLK pin configuration (pull-down) when not in use
             - Updates to blhost version 2.6.5 (fixes firmware update problems on macOS)
             - Allows USBSIO GPIO bridge interface on MCU-Link Pro (despite not having a dedicated
               pin for GPIO; one of the other I2C/SPI pins can be re-configured for GPIO if needed)

 - V2.263 - Introduces support for Power Profiling

 - V2.250 - Includes updated SEGGER MCU-Link firmware 210930
          - Supports GPIO triggering for analog measurements
          - Includes a second VCOM interface (MCU-Link Pro, optional on MCU-Link on-board)
          - Allows SWO link speeds up to 9.6 Mbits/s
          - Initialize/un-initialize debug pins on debug session connect/disconnect
          - Bugfix: wire reset not working

 - V2.245 - Introduces support for MCU-Link on-board and Pro probes
               Adds Voltage/Power Measurement support for MCU-Link OB and Pro probes
               Adds SPI/I2C/GPIO bridge interface (USBSIO)
               Include SEGGER firmware which makes MCU-Link compatible with J-Link LITE

 - V1.098 - First MCU-Link production firmware release
               Includes:
               - drivers for Windows operating systems
               - Udev rules for Linux operating systems


Feature Set
===========

The current release of the firmware provides the following features:
    - CMSIS-DAP 2.1 support (available in MCUXpresso IDE 11.7.0 or newer)
    - Support for SWD debugging from MCUXpresso IDE (and other CMSIS-DAP compatible IDEs)
    - Support for SWO Trace capture from MCUXpresso IDE (and other CMSIS-DAP compatible IDEs)
    - VCOM - UART bridge connected to the target processor
    - Support for target boot configuration control using ISP CTRL pin(s)
      (available in MCUXpresso IDE 11.7.0 or newer)
    - MCU-Link Pro and MCU-Link on-board features
        - Support for a second VCOM interface (optional on MCU-Link on-board)
        - USBSIO - USB bridge to SPI/I2C/GPIO connected to the target processor
          (Note: USBSIO I2C and SWO Trace capture functionalities are mutually exclusive)
        - Voltage/Current/Power measurement support (available in MCUXpresso IDE 11.4.1 or newer)
        - GPIO triggering for analog measurements (available in MCUXpresso IDE 11.5.0 or newer)
        - Power profiling support (available in MCUXpresso IDE 11.6.0 or newer)

The name (product string) is of the form:
"MCU-LINK [Pro|MR|on-board|<board_name>] (r<RRR>) CMSIS-DAP V<V>.<BBB>" where
 - <board_name> is the target BoardName string if avaiable (see Firmware Configuration)
 - <RRR> is the hardware configuration,
 - <V> is the firmware version (3) and 
 - <BBB> is a non-zero build number.


Host Configuration
===================

Windows hosts
    An optional inf-only driver is provided to allow displaying friendly names for the
    MCU-Link VCom Port(s) in Device Manager.

    The driver is automatically installed as part of the firmware update utility installation.
    In case manual installation is needed, navigate to <Install Dir>\drivers and install the
    driver by right-click > Install on the *.inf file:
      - mcu-link-vcom.inf

Linux hosts
    A set of Udev rules is provided for MCU-Link USB Devices to allow read-write access for
    all users. Udev rules are automatically added by the firmware uptate utility installation.
    In case manual installation is needed, copy <Install Dir>/drivers/85-mcu-link.rules to
    /lib/udev/rules.d (it requires root/sudo permissions).


Probe Configuration
===================

The support for standard features can be controlled via jumpers on board:
 - For example, on MCU-Link board:
    - SWD debug including SWO trace can be disabled through J5 jumper
    - VCOM can be disabled through J4 jumper
 - MCU-Link Pro includes the following jumpers to control features:
    - SWD debug including SWO trace can be disabled through J13 jumper
    - VCOM can be disabled through J14 jumper
    - USB-SIO can be disabled through J15 jumper
- For MCU-Link on-board versions please consult the board documentation for the available jumpers


Firmware Configuration
======================

Even though the firmware image is identical for all MCU-Link-based probes, it is possible to store
persistent configuration parameters that the firmware can read at runtime and make use of to customize
its behavior.
This capability is used to implement target identification strings via DAP_Info command. This is useful
for on-board debug probe variants, which are always connected to a fixed known target device.
In this case Device Vendor, Device Name, Board Vendor and Board Name strings are stored and may be used
by debuggers or IDEs to perform additional auto-configuration.

The program_CMSIS utility has been extended with command-line arguments to allow storing the
target specific information data as part of the firmware programming process:
  --target=DeviceVendor:DeviceName:BoardVendor:BoardName    -> stores the specified target strings
  --no-target                                               -> clears any existing target strings

The strings should match the listed attribute values from the corresponding CMSIS Board Support Pack:
 - DeviceVendor should match the Dvendor attribute value (excluding the colon and vendor code suffix
   when present) of the mountedDevice.
 - DeviceName should match the Dname attribute value of the mountedDevice.
 - BoardVendor should match the vendor attribute value (excluding the colon and vendor code suffix).
 - BoardName should match the name attribute value.

For example, when programming CMSIS-DAP firmware on an MIMXRT1064-EVK board, call the program script:
    <Install Dir>\scripts\program_CMSIS --target=NXP:MIMXRT1064xxxxA:NXP:EVK-MIMXRT1064 

Notes:
- Once stored, the target strings are persistent across subsequent firmware programming operations, so
  they can usually be omitted afterwards. The strings are cleared when using the --no-target argument.
- Board designs which include a debug probe often allow the possibility to use the on-board probe to
  debug some other external target. If this capability is used, the target identification strings should
  be removed.


===============
SEGGER Firmware
===============

SEGGER offers a firmware running on the NXP MCU-Link / MCU-Link on-board platform which makes
it compatible with J-Link LITE.
    - Supports all ARM based NXP devices which are also supported by J-Link LITE
    - JTAG, SWD + SWO supported
    - VCOM
    - Fully compatible with and same features as J-Link LITE

For more information please consult:
https://www.segger.com/products/debug-probes/j-link/models/other-j-links/mcu-link

NOTE: The J-Link firmware only supports MCU-Link Pro and MCU-Link on-board systems that use
an LPC55S69 in LQFP100 or BGA98 package.
Although the firmware can be programmed in to MCU-Link and MCU-Link on-board systems that
use LQFP64 package, the firmware will not run.


===========================
Firmware Installation Guide
===========================

This firmware installation guide is suitable for Windows, Linux and macOS environments

Scripts are supplied to enable the programming of NXP CMSIS-DAP and SEGGER J-Link firmware
images into MCU-Link.

To make use of this functionality, place the board in ISP USB mode using the
appropriate jumper on your MCU-Link board, then connect it to the host computer via USB.
Refer to the board documentation for more information.

To install CMSIS-DAP firmware, open a command prompt and call the program script:
    <Install Dir>\scripts\program_CMSIS

To install J-Link firmware, open a command prompt and call the program script:
    <Install Dir>\scripts\program_JLINK

The script programs the firmware image into flash using blhost utility.
Once completed, follow the on-screen instructions to make use of the programmed debug probe.

Further information about the use of blhost is available in the User Guide
https://www.nxp.com/docs/en/user-guide/MCUBLHOSTUG.pdf

Note:
    The script offers the option to repeat the programming sequence to enable
    multiple debug probes to be programmed in sequence.
